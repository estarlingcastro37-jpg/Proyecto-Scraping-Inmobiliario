
import sys
import pandas as pd
from ydata_profiling import ProfileReport
archivo_entrada, archivo_salida = sys.argv[1:3]
df = pd.read_csv(archivo_entrada)
reporte = ProfileReport(df, title='Reporte de propiedades', minimal=True, explorative=False)
reporte.to_file(archivo_salida)
